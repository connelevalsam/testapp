from django.urls import path
from . import views

urlpatterns = [
    path('', views.home_view, name='home'),
    path('reach-us/', views.reach_us_view, name='reach_us'),
    path('test/', views.test_view, name='test'),
    path('all-products/', views.product_list_view, name='list-products'),
    path('all-products/<int:id>/', views.product_detail_view, name='detail-product'),
]
