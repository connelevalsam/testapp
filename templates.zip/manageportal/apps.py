from django.apps import AppConfig


class ManageportalConfig(AppConfig):
    name = 'manageportal'
