from django.contrib import admin
from .models import Message, Transaction, FeatureProducts


class ManageAdmin(admin.ModelAdmin):
    list_display = ('fullname', 'description', 'address', 'email', 'uploaded_at')

class Feature(admin.ModelAdmin):
    list_display = ('event_name', 'name', 'photo', 'start_date', 'end_date')


admin.site.register(Message, ManageAdmin)

admin.site.register(Transaction)

admin.site.register(FeatureProducts, Feature)
