from django.urls import path
from . import views

urlpatterns = [
    path('', views.admin_home, name='adminhome'),
    path('messages/', views.MessageListView.as_view(), name='messages'),
    path('message/<int:pk>', views.MessageDetailView.as_view(), name='message-detail'),

    path('profits/', views.profit_view, name='profits'),
    path('profit-list/<int:pk>', views.transaction_detail_view, name='transaction-detail'),
    path('transaction-of/<int:id>/', views.transaction_view, name='transaction'),

    path('message-rejected/<int:id>', views.reject_message, name='message-reject'),
    path('message-accepted/<int:id>', views.accept_message, name='message-accept'),
    path('waiting-messages/', views.waiting_list, name='waiting-list'),
    path('rejected-messages/', views.rejected_list, name='rejected-list'),
    path('accepted-messages/', views.accepted_list, name='accepted-list'),

    path('features/', views.feature_view, name='features'),
    path('features/create/', views.feature_view_create, name='feature_create'),
    path('features/save/', views.feature_view_save, name='feature_save'),

    path('coupons/', views.coupons_view, name='coupons'),
]
